Most of the code in the plug comes from various examples in the LV2 distribution and
example plugins. As such, the source code of the LV2 plugin version of `sfizz` is
distributed under the same terms as the LV2 specification, which is the ISC license.
Check the LICENSE.md at (https://github.com/sfztools/sfizz) file for more
information about the license of the source code of the `sfizz` library and its
contributors.

The `sfizz` LV2 plugin can be optionally statically built against `libsndfile`
from Erik de Castro Lopo (http://www.mega-nerd.com/libsndfile). `libsndfile`
is distributed under the terms of the LGPL v2 or v3. If you distribute a
statically-linked LV2 version of `sfizz` built against `libsndfile`, you need
to respect the terms of the LGPL v2 or v3 license.
